
import pygame
import os
import random as rd
import json
import sys
import pickle

# BASIC INFO
pygame.init()
FPS = 60  # frames per second
clock = pygame.time.Clock()  # control fps

# Screen information
WIDTH = 1200
HEIGHT = 600
SIZE = WIDTH, HEIGHT
DISPLAYSURF = pygame.display.set_mode(SIZE)
background_image = pygame.image.load("pxfuel.jpg")

# Color used
RED = (255, 0, 0)
BLUE = (102, 178, 255)
LIGHTBLUE = (165, 217, 250)
GRAY = (157, 157, 157)
PURPLE = (27, 31, 64)
BLACK = (0, 0, 0)
RECT_COLOR = pygame.Color(PURPLE)       # color of the ground

# Icon and window name
pygame.display.set_caption("CASTLES WAR")
programIcon = pygame.image.load('logo.png')
pygame.display.set_icon(programIcon)

#CONSTANTS
# initial number of resources
INIT_RESOURCES = INIT_RESOURCES1 = INIT_RESOURCES2 = 100

#Building constants
# Tower constants
TOWER_HEALTH = 1000
TOWER_RANGE_1 = 500
TOWER_RANGE_2 = 400
TOWER_HIT = 11
TOWER_POS = 225
TOWER_WIDTH = 62
TOWER_HEIGHT = 240

# Mine constants
MINE_POS = 0
MINE_WIDTH = 58
MINE_HEIGHT = 37

# Barracks constants
BARRACKS_POS = 80
BARRACK_WIDTH = 62
BARRACK_HEIGHT = 50

# Ground constants
GROUND_HEIGHT = 525     # height of the ground
bottom_rect = pygame.Rect(0, GROUND_HEIGHT, 1200, HEIGHT - GROUND_HEIGHT)

# Units constants
# Soldier
SOLDIER_POS = 165
SOLDIER_COST = 5
SOLDIER_TRAIN = 20
SOLDIER_RANGE = 10
SOLDIER_SPEED = 1
SOLDIER_HIT = 2
SOLDIER_HEALTH = 24
SOLDIER_WIDTH = 16
SOLDIER_HEIGHT = 20

# Worker
WORKER_POS = 115
WORKER_COST = 2
WORKER_TRAIN = 20
WORKER_SPEED = 1
WORKER_PROD = 3
WORKER_REPAIR = 2
WORKER_WIDTH = 16
WORKER_HEIGHT = 20

# Archer
ARCHER_POS = 215
ARCHER_COST = 7
ARCHER_TRAIN = 40
ARCHER_SPEED = 2
ARCHER_REST = 40
ARCHER_HIT = 8
ARCHER_HEALTH = 30
ARCHER_WIDTH = 17
ARCHER_HEIGHT = 23

# Arrow
ARROW_VEL = 5

# Commands of the keyboard
WORKER1_TRAIN = 'q'
SOLDIER1_TRAIN = 'w'
ARCHER1_TRAIN = 'e'
PL1_TO_MINE = 'a'
PL1_TO_WALL = 's'
SOLDIER1_ATTACK = 'd'
ARCHER1 = 'f'
UNLEASH1 = 'z'

WORKER2_TRAIN = 'p'
SOLDIER2_TRAIN = 'o'
ARCHER2_TRAIN = 'i'
PL2_TO_MINE = 'l'
PL2_TO_WALL = 'k'
SOLDIER2_ATTACK = 'j'
ARCHER2 = 'h'
UNLEASH2 = 'm'

PAUSE = ' '
SAVE = 'V'
LOAD = 'B'

# font used
font_number1 = pygame.font.SysFont('Sans Serif', 27)
font_number2 = pygame.font.SysFont('Sans Serif', 20)
font_number3 = pygame.font.SysFont('Sans Serif', 24)
font_number4 = pygame.font.SysFont('Sans Serif', 50)
winning_font = pygame.font.SysFont("freesansbold.ttf", 70)  # for both red and blue


# Loading the sprites
# Barracks 1 (red)
Redbarrack = pygame.transform.scale(pygame.image.load('sprites/player1/building/barracks.png'), (BARRACK_WIDTH, BARRACK_HEIGHT))

# Barrack 2 (blue)
Bluebarrack = pygame.transform.scale(pygame.image.load('sprites/player2/building/barracks.png'), (BARRACK_WIDTH, BARRACK_HEIGHT))

# Soldier 1 (red)
ready_1_soldier = pygame.image.load(os.path.join('sprites', 'player1', 'sword', 'ready.png'))

run_1_soldier = []
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-1.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-2.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-3.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-4.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-5.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-6.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-7.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-8.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-9.png'))
run_1_soldier.append(pygame.image.load('sprites/player1/sword/run-10.png'))

attack_1_soldier = []
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-0.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-1.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-2.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-3.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-4.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-5.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-6.png'))
attack_1_soldier.append(pygame.image.load('sprites/player1/sword/attack-7.png'))

dead_1_soldier = []
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-0.png'))
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-1.png'))
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-2.png'))
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-3.png'))
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-4.png'))
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-5.png'))
dead_1_soldier.append(pygame.image.load('sprites/player1/sword/dead-5.png'))

# Worker 1 (red)
worker_1_ready = pygame.transform.flip((pygame.image.load(os.path.join('sprites', 'player1', 'worker', 'ready.png'))), True, False)

# flip the image because it is going in the opposite direction to the mine
run_1_workers_mine = []
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-1.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-2.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-3.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-4.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-5.png'), True, False))

run_1_workers_tower = []
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-1.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-2.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-3.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-4.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-5.png'))

mine_1_worker = []
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-0.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-1.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-2.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-3.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-4.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-5.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-6.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-7.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-8.png'), True, False))

repair_1_worker = []
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-0.png'))
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-1.png'))
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-2.png'))
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-3.png'))

# Archer 1 (red)
ready_1_archer = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'ready.png'))
arrow_1 = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'arrowhor-0.png'))

run_1_archer = []
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-1.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-2.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-3.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-4.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-5.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-6.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-7.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-8.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-9.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-10.png'))
run_1_archer.append(pygame.image.load('sprites/player1/bow/run-11.png'))

shoot_1_archer = []
shoot_1_archer.append(pygame.image.load('sprites/player1/bow/shoot-0.png'))
shoot_1_archer.append(pygame.image.load('sprites/player1/bow/shoot-1.png'))

dead_1_archer = []
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-0.png'))
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-1.png'))
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-2.png'))
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-3.png'))
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-4.png'))
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-5.png'))
dead_1_archer.append(pygame.image.load('sprites/player1/bow/dead-5.png'))

# Soldier 2 (blue)
ready_2_soldier = pygame.image.load(os.path.join('sprites', 'player2', 'sword', 'ready.png'))

run_2_soldier = []
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-1.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-2.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-3.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-4.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-5.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-6.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-7.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-8.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-9.png'))
run_2_soldier.append(pygame.image.load('sprites/player2/sword/run-10.png'))

attack_2_soldier = []
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-0.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-1.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-2.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-3.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-4.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-5.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-6.png'))
attack_2_soldier.append(pygame.image.load('sprites/player2/sword/attack-7.png'))

dead_2_soldier = []
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-0.png'))
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-1.png'))
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-2.png'))
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-3.png'))
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-4.png'))
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-5.png'))
dead_2_soldier.append(pygame.image.load('sprites/player2/sword/dead-5.png'))

# Worker 2 (blue)
ready_2_worker = pygame.transform.flip((pygame.image.load(os.path.join('sprites', 'player2', 'worker', 'ready.png'))), True, False)

# flip the image because it is going in the opposite direction to the mine
run_2_workers_mine = []
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-1.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-2.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-3.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-4.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-5.png'), True, False))

run_2_workers_tower = []
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-1.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-2.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-3.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-4.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-5.png'))

mine_2_worker = []
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-0.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-1.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-2.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-3.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-4.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-5.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-6.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-7.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-8.png'), True, False))

repair_2_worker = []
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-0.png'))
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-1.png'))
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-2.png'))
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-3.png'))

# Archer 1 (red)
ready_2_archer = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'ready.png'))
arrow_2 = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'arrowhor-0.png'))

run_2_archer = []
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-1.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-2.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-3.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-4.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-5.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-6.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-7.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-8.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-9.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-10.png'))
run_2_archer.append(pygame.image.load('sprites/player2/bow/run-11.png'))

shoot_2_archer = []
shoot_2_archer.append(pygame.image.load('sprites/player2/bow/shoot-0.png'))
shoot_2_archer.append(pygame.image.load('sprites/player2/bow/shoot-1.png'))

dead_2_archer = []
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-0.png'))
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-1.png'))
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-2.png'))
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-3.png'))
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-4.png'))
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-5.png'))
dead_2_archer.append(pygame.image.load('sprites/player2/bow/dead-5.png'))

# CLASSES
# CLASS 1: SOLDIER
class Soldier(pygame.sprite.Sprite):
    total_soldiers_created = 0
    def __init__(self, player, sprites_ready, sprites_run, sprites_attack, sprites_dead):
        super().__init__()

        self.player = player  # To identify player 1 and player 2

        self.unleash = False
        self.is_attack_units = False
        self.is_attack_tower = False
        self.is_dead = False

        # Connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.attack = sprites_attack
        self.dead_sprites = sprites_dead
        self.image = self.ready
        self.tic = 0
        self.index = 0
        self.time = 0
        self.health = SOLDIER_HEALTH
        self.rect = self.image.get_rect()

        # Set initial position based on the player
        if self.player == 1:
            self.rect.left = BARRACKS_POS + (BARRACK_WIDTH / 2)
        else:
            self.rect.right = WIDTH - BARRACKS_POS - (BARRACK_WIDTH / 2)
        self.rect.bottom = GROUND_HEIGHT

    def update(self):
        self.time += 1
        if self.time > SOLDIER_TRAIN and self.unleash and not self.is_attack_units and not self.is_attack_tower:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            if self.player == 1:
                self.rect.x += SOLDIER_SPEED
            else:
                self.rect.x -= SOLDIER_SPEED

        # If a soldier is attacking a unit or the tower, display the correct sprites
        if self.is_attack_units or self.is_attack_tower:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.attack):
                self.index = 0

            self.image = self.attack[self.index]

        # Check if a unit is dead
        if self.health <= 0:
            if self.player == 1:
                self.rect.x -= SOLDIER_SPEED
            else:
                self.rect.x += SOLDIER_SPEED

            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.dead_sprites):
                self.index = 0
                self.kill()

            self.image = self.dead_sprites[self.index]

# CLASS 2: WORKER
class Worker(pygame.sprite.Sprite):
    def __init__(self, player_num, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair):
        super().__init__()

        self.player_num = player_num
        self.gotominer = False
        self.gototower = False
        self.is_at_mine = False
        self.is_at_wall = False

        self.ready = sprites_ready
        self.run_mine = sprites_run_mine
        self.run_tower = sprites_run_tower
        self.mine = sprites_mine
        self.repair = sprites_repair
        self.image = self.ready
        self.tic = 0
        self.index = 0
        self.time = 0

        if player_num == 1:
            self.rect = self.image.get_rect(left=BARRACKS_POS + (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)
        else:
            self.rect = self.image.get_rect(right=WIDTH - BARRACKS_POS - (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        if self.time > WORKER_TRAIN and self.is_at_mine == False and self.gotominer == True and self.is_at_wall == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run_mine):
                self.index = 0

            if self.player_num == 1:
                self.rect.x -= WORKER_SPEED
            else:
                self.rect.x += WORKER_SPEED

            self.image = self.run_mine[self.index]

        if self.time > 100 and self.is_at_mine == False and self.gototower == True and self.is_at_wall == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run_tower):
                self.index = 0

            if self.player_num == 1:
                self.rect.x += WORKER_SPEED
            else:
                self.rect.x -= WORKER_SPEED

            self.image = self.run_tower[self.index]

        if self.is_at_mine == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.mine):
                self.index = 0

            self.image = self.mine[self.index]

        if self.is_at_wall == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.repair):
                self.index = 0

            self.image = self.repair[self.index]


class Worker_1(Worker):
    def __init__(self, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair):
        super().__init__(1, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair)

class Worker_2(Worker):
    def __init__(self, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair):
        super().__init__(2, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair)

# CLASS 3: ARCHER
class Archer_1(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run, sprites_shoot, sprites_dead):

        super().__init__()

        self.isshoot = False
        self.unleash = False
        self.is_dead = False

        # connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.shoot = sprites_shoot
        self.is_dead = sprites_dead
        self.image = self.ready
        self.tic = 0
        self.index = 0
        self.time = 0
        self.health = ARCHER_HEALTH

        self.rect = self.image.get_rect(left=BARRACKS_POS + (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        # possibility 1: unleashed archer
        if self.time > ARCHER_TRAIN and self.unleash == True and self.isshoot == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            self.rect.x += ARCHER_SPEED

        # possibility 2: shooting archer
        if self.isshoot == True:
            self.tic += 1
            if self.tic == ARCHER_REST:
                self.index = 1
            if self.tic == 230:
                self.index = 0
                self.tic = 0
            if self.index >= len(self.shoot):
                self.index = 0

            self.image = self.shoot[self.index]

        # possibility 3: archer die
        if self.health <= 0:
            self.kill()

class Archer_2(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run, sprites_shoot, sprites_dead):

        super().__init__()

        self.isshoot = False
        self.unleash = False
        self.is_dead = False

        # connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.shoot = sprites_shoot
        self.image = self.ready
        self.tic = 0
        self.index = 0
        self.time = 0
        self.health = ARCHER_HEALTH

        self.rect = self.image.get_rect(right=WIDTH - BARRACKS_POS - (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        # possibility 1: unleashed archer
        if self.time > ARCHER_TRAIN and self.unleash == True and self.isshoot == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            self.rect.x -= ARCHER_SPEED

        # possibility 2: shooting archer
        if self.isshoot == True:
            self.tic += 1
            if self.tic == ARCHER_REST:
                self.index = 1
            if self.tic == 230:
                self.index = 0
                self.tic = 0
            if self.index >= len(self.shoot):
                self.index = 0

            self.image = self.shoot[self.index]

        # possibility 3: archer die
        if self.health <= 0:
            self.kill()

# Arrow 1 (red)
tower_1_arrows_pos_1 = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'arrowdiag-0.png'))
tower_1_arrows_pos_2 = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'arrowdiag-0.png'))

class Arrow_1(pygame.sprite.Sprite):
    def __init__(self, arrow_1):
        super().__init__()

        self.image = arrow_1
        self.rect = self.image.get_rect(left= 685, top=GROUND_HEIGHT - (ARCHER_HEIGHT/2) - 3)          # 685: average between the position in which the archer can start shooting. 3: extra height of the arrow from the ground

    def update(self):
        self.rect.x += ARROW_VEL


class Tower_1_arrows_pos_1(pygame.sprite.Sprite):
    def __init__(self, tower_1_arrows_pos_1):
        super().__init__()

        self.image = tower_1_arrows_pos_1
        self.rect = self.image.get_rect(left=TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x += 6
        self.rect.y += 4

class Tower_1_arrows_pos_2(pygame.sprite.Sprite):
    def __init__(self, tower_1_arrows_pos_2):
        super().__init__()

        self.image = tower_1_arrows_pos_2
        self.rect = self.image.get_rect(left=TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x += 3
        self.rect.y += 4

# Arrow 2 (blue)
tower_2_arrow_pos_1 = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'arrowdiag-0.png'))
tower_2_arrow_pos_2 = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'arrowdiag-0.png'))

class Arrow_2(pygame.sprite.Sprite):
    def __init__(self, arrow_2):
        super().__init__()

        self.image = arrow_2
        self.rect = self.image.get_rect(right=WIDTH - 685, top = GROUND_HEIGHT - (ARCHER_HEIGHT/2) - 3)          # 685: average between the position in which the archer can start shooting. 3: extra height of the arrow from the ground
    def update(self):
        self.rect.x -= ARROW_VEL


class Tower_2_arrow_pos_1(pygame.sprite.Sprite):
    def __init__(self, tower_2_arrow_pos_1):
        super().__init__()

        self.image = tower_2_arrow_pos_1
        self.rect = self.image.get_rect(left=WIDTH - TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x -= 6
        self.rect.y += 4

class Tower_2_arrow_pos_2(pygame.sprite.Sprite):
    def __init__(self, tower_2_arrow_pos_2):
        super().__init__()

        self.image = tower_2_arrow_pos_2
        self.rect = self.image.get_rect(left=WIDTH - TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x -= 3
        self.rect.y += 4

# Tower 1 (red)
Redtower = []
Redtower.append(pygame.transform.scale(pygame.image.load('sprites/player1/building/tower2.png'), (TOWER_WIDTH, TOWER_HEIGHT)))

class Tower_1_red(pygame.sprite.Sprite):
    def __init__(self, Redtower):
        super(Tower_1_red, self).__init__()

        self.index = 0
        self.image = Redtower[self.index]

        self.rect = self.image.get_rect(right=TOWER_POS, bottom=GROUND_HEIGHT)

# Tower 2 (blue)
Bluetower = []
Bluetower.append(pygame.transform.scale(pygame.image.load('sprites/player2/building/tower2.png'), (TOWER_WIDTH, TOWER_HEIGHT)))

class Tower_2_blue(pygame.sprite.Sprite):
    def __init__(self, Bluetower):
        super(Tower_2_blue, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Bluetower[self.index]

        self.rect = self.image.get_rect(right=WIDTH - TOWER_POS + self.image.get_width(), bottom=GROUND_HEIGHT)

# Mine 1 (red)
Redmines = []
Redmines.append(pygame.transform.scale(pygame.image.load('sprites/player1/building/mine.png'), (MINE_WIDTH, MINE_HEIGHT)))

class Mine_1_red(pygame.sprite.Sprite):
    def __init__(self, Redmines):
        super(Mine_1_red, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Redmines[self.index]

        self.rect = self.image.get_rect(left=0, bottom=GROUND_HEIGHT)

    def update(self):
        self.tic += 1
        if self.tic == 11:
            self.index += 1
            self.tic = 0

        if self.index >= len(Redmines):
            self.index = 0

        self.image = Redmines[self.index]

# Mine 2 (blue)
Bluemines = []
Bluemines.append(pygame.transform.scale(pygame.image.load('sprites/player2/building/mine.png'), (MINE_WIDTH, MINE_HEIGHT)))

class Mine_2_blue(pygame.sprite.Sprite):
    def __init__(self, Bluemines):
        super(Mine_2_blue, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Bluemines[self.index]

        self.rect = self.image.get_rect(right=WIDTH, bottom=GROUND_HEIGHT)

    def update(self):
        self.tic += 1
        if self.tic == 9:
            self.index += 1
            self.tic = 0

        if self.index >= len(Bluemines):
            self.index = 0

        self.image = Bluemines[self.index]


def manage_soldiers(Soldier_1_list, Soldier_2_list, Tower_1_red_list, Tower_2_blue_list):

    # collision between swordsman

    for soldier in Soldier_2_list:
        if pygame.sprite.spritecollideany(soldier, Soldier_1_list):
            soldier.is_attack_units = True

        elif pygame.sprite.spritecollideany(soldier, Tower_1_red_list):
            soldier.is_attack_tower = True

        else:
            soldier.is_attack_units = False


    for soldier in Soldier_1_list:
        if pygame.sprite.spritecollideany(soldier, Soldier_2_list):
            soldier.is_attack_units = True

        elif pygame.sprite.spritecollideany(soldier, Tower_2_blue_list):
            soldier.is_attack_tower = True

        else:
            soldier.is_attack_units = False


    # soldier taking damage
    damage_constant = 7

    for soldier in Soldier_2_list:
        if soldier.is_attack_units == True:
            for soldier in Soldier_1_list:
                if soldier.is_attack_units == True:
                    soldier.health -= SOLDIER_HIT / damage_constant


    for soldier in Soldier_1_list:
        if soldier.is_attack_units == True:
            for soldier in Soldier_2_list:
                if soldier.is_attack_units == True:
                    soldier.health -= SOLDIER_HIT / damage_constant

def manage_workers(Worker_1_list, Worker_2_list, Mine_1_red_list, Mine_2_blue_list, Tower_1_red_list, Tower_2_blue_list):

    # collision between worker and mine and/or tower

    # check if worker1 reach the mine
    for worker in Worker_1_list:
        if pygame.sprite.spritecollideany(worker, Mine_1_red_list):
            worker.is_at_mine = True

    # check if worker1 reach the wall
    for worker in Worker_1_list:
        if pygame.sprite.spritecollideany(worker, Tower_1_red_list):
            worker.is_at_wall = True


    # check if worker2 reach the mine
    for worker in Worker_2_list:
        if pygame.sprite.spritecollideany(worker, Mine_2_blue_list):
            worker.is_at_mine = True


    # check if worker1 reach the wall
    for worker in Worker_2_list:
        if pygame.sprite.spritecollideany(worker, Tower_2_blue_list):
            worker.is_at_wall = True

def manage_archers(Soldier_1_list, Soldier_2_list, Archer_1_list, Archer_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2, Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2):

    # check if archer1 reach the shooting position
    for archer in Archer_1_list:
        if archer.rect.x >= rd.randint(640, 670):
            archer.isshoot = True

    # check if archer2 reach the shooting position
    for archer in Archer_2_list:
        if archer.rect.x <= rd.randint(WIDTH - 670, WIDTH - 640):
            archer.isshoot = True

    # archer1 collision with arrow, and health damage
    for archer in Archer_1_list:
        for arrow in Arrow_2_list:
            if pygame.sprite.spritecollideany(archer, Arrow_2_list):
                Arrow_2_list.remove(arrow)
                for archer in Archer_1_list:
                    if archer.isshoot == True:
                        archer.health -= ARCHER_HIT

    # archer2 collision with arrow + health damage
    for archer in Archer_2_list:
        for arrow in Arrow_1_list:
            if pygame.sprite.spritecollideany(archer, Arrow_1_list):
                Arrow_1_list.remove(arrow)
                for archer in Archer_2_list:
                    if archer.isshoot == True:
                        archer.health -= ARCHER_HIT

    # soldier collision with arrows, tower arrows and archer
    for soldier in Soldier_1_list:
        for arrow in Arrow_2_list:
            if pygame.sprite.spritecollideany(soldier, Arrow_2_list):
                Arrow_2_list.remove(arrow)
                soldier.health -= ARCHER_HIT

        for arrow in Tower_2_arrow_list_pos_1:
            if pygame.sprite.spritecollideany(soldier, Tower_2_arrow_list_pos_1):
                Tower_2_arrow_list_pos_1.remove(arrow)
                soldier.health -= TOWER_HIT

        for arrow in Tower_2_arrow_list_pos_2:
            if pygame.sprite.spritecollideany(soldier, Tower_2_arrow_list_pos_2):
                Tower_2_arrow_list_pos_2.remove(arrow)
                soldier.health -= TOWER_HIT

        if pygame.sprite.spritecollideany(soldier, Archer_2_list):
            soldier.is_attack_units = True
            if soldier.is_attack_units == True:
                for archer in Archer_2_list:
                    if archer.isshoot == True:
                        archer.health -= SOLDIER_HIT / 10

    for soldier in Soldier_2_list:
        for arrow in Arrow_1_list:
            if pygame.sprite.spritecollideany(soldier, Arrow_1_list):
                Arrow_1_list.remove(arrow)
                soldier.health -= ARCHER_HIT

        for arrow in Tower_1_arrows_list_pos_1:
            if pygame.sprite.spritecollideany(soldier, Tower_1_arrows_list_pos_1):
                Tower_1_arrows_list_pos_1.remove(arrow)
                soldier.health -= TOWER_HIT

        for arrow in Tower_1_arrows_list_pos_2:
            if pygame.sprite.spritecollideany(soldier, Tower_1_arrows_list_pos_2):
                Tower_1_arrows_list_pos_2.remove(arrow)
                soldier.health -= TOWER_HIT

        if pygame.sprite.spritecollideany(soldier, Archer_1_list):
            soldier.is_attack_units = True
            if soldier.is_attack_units == True:
                for archer in Archer_1_list:
                    if archer.isshoot == True:
                        archer.health -= SOLDIER_HIT / 10

# RESUME GAME
def resume_game():

    # save file
    #print(type(game_stats))
    #print(game_stats)

    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 128))   # 128 is the alpha value for transparency (to make game screen partially visible but not blurred)

    play_again_text = font_number4.render(' -- press SPACE to resume --', True, "WHITE")
    play_again_rect = play_again_text.get_rect()
    play_again_rect.center = (WIDTH // 2, HEIGHT // 2)

    save_game_text = font_number3.render(' -- press v to save the game --', True, "WHITE")
    save_game_rect = save_game_text.get_rect()
    save_game_rect.center = (WIDTH // 2, HEIGHT // 2+40)

    DISPLAYSURF.blit(overlay, (0, 0))
    DISPLAYSURF.blit(play_again_text, play_again_rect)
    DISPLAYSURF.blit(save_game_text, save_game_rect)
    pygame.display.update()

    resume = False
    while not resume:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                resume = True

            # save file here
            if event.type == pygame.KEYDOWN and event.key == pygame.K_v:
                # save file
                with open('save_stats.txt', 'w') as save_file:
                    json.dump(game_stats, save_file)

            if event.type == pygame.QUIT:
                sys.exit()

# DISPLAY SETTINGS:
def draw_text(GAME_START, game_stats, Soldier_1_list, Soldier_2_list, Worker_1_list, Worker_2_list, Archer_1_list, Archer_2_list):
    # variables used for displaying text:

    # SOLDIER
    soldier_text_1 = font_number3.render(str(len(Soldier_1_list)), True, pygame.Color("red"))
    soldier_text_2 = font_number3.render(" -- soldier alive -- ", True, pygame.Color("white"))
    soldier_text_3 = font_number3.render(str(len(Soldier_2_list)), True, pygame.Color(BLUE))
    soldier_text = pygame.Surface((soldier_text_1.get_width() + soldier_text_2.get_width() + soldier_text_3.get_width(), soldier_text_1.get_height()), pygame.SRCALPHA)
    soldier_text.blit(soldier_text_1, (0, 0))
    soldier_text.blit(soldier_text_2, (soldier_text_1.get_width(), 0))
    soldier_text.blit(soldier_text_3, (soldier_text_1.get_width() + soldier_text_2.get_width(), 0))

    soldier_text_rect = soldier_text.get_rect()
    soldier_text_rect.center = (WIDTH // 2, GROUND_HEIGHT + 20*1)


    # ARCHER
    archer_text_1 = font_number3.render(str(len(Archer_1_list)), True, pygame.Color("red"))
    archer_text_2 = font_number3.render(" -- archer alive -- ", True, pygame.Color("white"))
    archer_text_3 = font_number3.render(str(len(Archer_2_list)), True, pygame.Color(BLUE))
    archer_text = pygame.Surface((archer_text_1.get_width() + archer_text_2.get_width() + archer_text_3.get_width(), archer_text_1.get_height()), pygame.SRCALPHA)
    archer_text.blit(archer_text_1, (0, 0))
    archer_text.blit(archer_text_2, (archer_text_1.get_width(), 0))
    archer_text.blit(archer_text_3, (archer_text_1.get_width() + archer_text_2.get_width(), 0))

    archer_text_rect = archer_text.get_rect()
    archer_text_rect.center = (WIDTH // 2, GROUND_HEIGHT + 20*2)


    # WORKER
    worker_text_1 = font_number3.render(str(len(Worker_1_list)), True, pygame.Color("red"))
    worker_text_2 = font_number3.render(" -- worker alive -- ", True, pygame.Color("white"))
    worker_text_3 = font_number3.render(str(len(Worker_2_list)), True, pygame.Color(BLUE))
    worker_text = pygame.Surface((worker_text_1.get_width() + worker_text_2.get_width() + worker_text_3.get_width(), worker_text_1.get_height()), pygame.SRCALPHA)
    worker_text.blit(worker_text_1, (0, 0))
    worker_text.blit(worker_text_2, (worker_text_1.get_width(), 0))
    worker_text.blit(worker_text_3, (worker_text_1.get_width() + worker_text_2.get_width(), 0))

    worker_text_rect = worker_text.get_rect()
    worker_text_rect.center = (WIDTH // 2, GROUND_HEIGHT + 20*3)

    # opening display
    play_text = font_number4.render("PRESS 'ENTER' TO START A NEW GAME", True, "WHITE")
    play_rect = play_text.get_rect()
    play_rect.center = (WIDTH // 2, HEIGHT // 2 + 35)

    load_text = font_number4.render("PRESS 'B' TO BACKUP OLD GAME", True, "WHITE")
    load_rect = load_text.get_rect()
    load_rect.center = (WIDTH // 2, HEIGHT // 2 + 70)

    title_text = font_number3.render("CASTLEWAR", True, "WHITE")
    title_rect = title_text.get_rect()
    title_rect.center = (WIDTH // 2, 30)

    # tower health and resources
    Tower_1_red_hp_text = font_number3.render(f'TOWER HEALTH: {game_stats["Tower_1_red_health"]}', True, RED)
    Tower_1_red_hp_rect = Tower_1_red_hp_text.get_rect()
    Tower_1_red_hp_rect.topleft = (len(str(Tower_1_red_hp_text)), 50)

    Tower_2_blue_hp_text = font_number3.render(f'TOWER HEALTH: {game_stats["Tower_2_blue_health"]}', True, BLUE)
    Tower_2_blue_hp_rect = Tower_2_blue_hp_text.get_rect()
    Tower_2_blue_hp_rect.topright = (WIDTH - len(str(Tower_2_blue_hp_text)), 50)

    resources_1_text = font_number3.render(f'RESOURCES: {game_stats["PL1_resources"]}', True, RED)
    resources_1_rect = resources_1_text.get_rect()
    resources_1_rect.topleft = (len(str(resources_1_text)), 70)

    resources_2_text = font_number3.render(f'RESOURCES: {game_stats["PL2_resources"]}', True, BLUE)
    resources_2_rect = resources_2_text.get_rect()
    resources_2_rect.topright = (WIDTH - len(str(resources_2_text)), 70)

    # the texts that have to appear only after the match starts are blit here
    if GAME_START == False:
        DISPLAYSURF.blit(title_text, title_rect)
        DISPLAYSURF.blit(play_text, play_rect)
        DISPLAYSURF.blit(load_text, load_rect)

    if GAME_START == True:
        DISPLAYSURF.blit(Tower_1_red_hp_text, Tower_1_red_hp_rect)
        DISPLAYSURF.blit(Tower_2_blue_hp_text, Tower_2_blue_hp_rect)
        DISPLAYSURF.blit(resources_1_text, resources_1_rect)
        DISPLAYSURF.blit(resources_2_text, resources_2_rect)

        DISPLAYSURF.blit(soldier_text, soldier_text_rect)
        DISPLAYSURF.blit(worker_text, worker_text_rect)
        DISPLAYSURF.blit(archer_text, archer_text_rect)


# draw and update all the elements displayed
def draw_window(GAME_START, game_stats, Soldier_1_list, Soldier_2_list, Worker_1_list, Worker_2_list,
                Archer_1_list, Archer_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2,
                Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2, Tower_1_red_list, Tower_2_blue_list, Mine_1_red_list, Mine_2_blue_list):

    # Display the "buildings"
    DISPLAYSURF.fill(LIGHTBLUE)
    DISPLAYSURF.blit(background_image, (0, 0))

    Tower_1_red_list.draw(DISPLAYSURF)
    Tower_1_red_list.update()

    Tower_2_blue_list.draw(DISPLAYSURF)
    Tower_2_blue_list.update()

    DISPLAYSURF.blit(Redbarrack, (80, GROUND_HEIGHT - BARRACK_HEIGHT))
    DISPLAYSURF.blit(Bluebarrack, (WIDTH - 80 - Bluebarrack.get_width(), GROUND_HEIGHT - BARRACK_HEIGHT))

    Mine_1_red_list.draw(DISPLAYSURF)
    Mine_1_red_list.update()

    Mine_2_blue_list.draw(DISPLAYSURF)
    Mine_2_blue_list.update()

    # display the units
    Soldier_1_list.draw(DISPLAYSURF)
    Soldier_1_list.update()

    Soldier_2_list.draw(DISPLAYSURF)
    Soldier_2_list.update()

    Worker_1_list.draw(DISPLAYSURF)
    Worker_1_list.update()

    Worker_2_list.draw(DISPLAYSURF)
    Worker_2_list.update()

    Archer_1_list.draw(DISPLAYSURF)
    Archer_1_list.update()

    Archer_2_list.draw(DISPLAYSURF)
    Archer_2_list.update()

    # Display the arrows
    Arrow_1_list.draw(DISPLAYSURF)
    Arrow_1_list.update()

    Arrow_2_list.draw(DISPLAYSURF)
    Arrow_2_list.update()

    Tower_1_arrows_list_pos_1.draw(DISPLAYSURF)
    Tower_1_arrows_list_pos_1.update()

    Tower_1_arrows_list_pos_2.draw(DISPLAYSURF)
    Tower_1_arrows_list_pos_2.update()

    Tower_2_arrow_list_pos_1.draw(DISPLAYSURF)
    Tower_2_arrow_list_pos_1.update()

    Tower_2_arrow_list_pos_2.draw(DISPLAYSURF)
    Tower_2_arrow_list_pos_2.update()

    pygame.draw.rect(DISPLAYSURF, RECT_COLOR, bottom_rect)  # bottom black ground

    draw_text(GAME_START, game_stats, Soldier_1_list, Soldier_2_list, Worker_1_list, Worker_2_list,
              Archer_1_list, Archer_2_list)

    pygame.display.update()

# MAIN FUNCTION

def main():

    # variables
    GAME_START = False
    enemy_in_range_pos_1 = False        # first range of the tower
    enemy_in_range_pos_2 = False        # second range of the tower

    # Create sprite Groups
    Soldier_1_list = pygame.sprite.Group()
    Soldier_2_list = pygame.sprite.Group()

    Worker_1_list = pygame.sprite.Group()
    Worker_2_list = pygame.sprite.Group()

    Archer_1_list = pygame.sprite.Group()
    Archer_2_list = pygame.sprite.Group()

    Arrow_1_list = pygame.sprite.Group()
    Arrow_2_list = pygame.sprite.Group()

    Tower_1_arrows_list_pos_1 = pygame.sprite.Group()
    Tower_2_arrow_list_pos_1 = pygame.sprite.Group()

    Tower_1_arrows_list_pos_2 = pygame.sprite.Group()
    Tower_2_arrow_list_pos_2 = pygame.sprite.Group()

    red_tower = Tower_1_red(Redtower)
    red_mines = Mine_1_red(Redmines)
    Tower_1_red_list = pygame.sprite.Group(red_tower)
    Mine_1_red_list = pygame.sprite.Group(red_mines)

    blue_tower = Tower_2_blue(Bluetower)
    blue_mines = Mine_2_blue(Bluemines)
    Tower_2_blue_list = pygame.sprite.Group(blue_tower)
    Mine_2_blue_list = pygame.sprite.Group(blue_mines)

    # Final counting
    global total_resources_1
    global total_resources_2

    # at the beginning set them to the initial value
    total_resources_1 = INIT_RESOURCES1
    total_resources_2 = INIT_RESOURCES2

    # counters
    counter_1 = 0
    counter_2 = 0
    Tower_1_redcount = 0
    Tower_2_bluecount = 0

    Arrow_1_counter = 0
    Arrow_2_counter = 0

    Tower_1_redhealth_count = 0
    Tower_2_bluehealth_count = 0

    # game_stats
    global game_stats               # dictionary that stores the game statistics
    game_stats = {"PL1_resources": INIT_RESOURCES, "PL2_resources": INIT_RESOURCES, "Tower_1_red_health": TOWER_HEALTH,
            "Tower_2_blue_health": TOWER_HEALTH}

    global backup_game

    while True:

        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_RETURN and GAME_START == False:     # pressing return the game
                    backup_game = False
                    #print(backup_game)

                    GAME_START = True

                if event.key == pygame.K_b and GAME_START == False:     # pressing return the game
                    #print("Load old game")
                    backup_game = True
                    #print(backup_game)

                    with open("save_stats.txt") as save_file:
                        saved_stats = json.load(save_file)
                    game_stats = saved_stats

                    background_rect = pygame.Rect(0, 0, WIDTH, HEIGHT)
                    pygame.draw.rect(DISPLAYSURF, (0, 0, 0), background_rect)

                    message_info_text = winning_font.render('Loading successful', True, "WHITE")
                    message_info_rect = message_info_text.get_rect()
                    message_info_rect.center = (WIDTH // 2, HEIGHT // 2)
                    DISPLAYSURF.blit(message_info_text, message_info_rect)
                    pygame.display.update()

                    pygame.time.delay(1500)

                    GAME_START = True


                if event.key == pygame.K_SPACE and GAME_START == True:  # pressing space the game
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                        resume_game()

                if GAME_START == True:

                    # controls for each key and the units it dispatches

                    # GENERATE THE UNITS, check if player has enough resources to generate corresponding unit type. If enough resources available, it generates the unit and deducts required resources.

                    # Player 1 units
                    # generate soldier 1
                    if event.key == pygame.K_w and game_stats['PL1_resources'] >= SOLDIER_COST:
                        #print(type(game_stats['PL1_resources']))
                        #print("user have "+ str(game_stats['PL1_resources']))
                        red_soldier = Soldier(1, ready_1_soldier, run_1_soldier, attack_1_soldier, dead_1_soldier)
                        Soldier_1_list.add(red_soldier)
                        game_stats['PL1_resources'] -= SOLDIER_COST

                    # generate worker 1
                    if event.key == pygame.K_q and game_stats['PL1_resources'] >= WORKER_COST:
                        red_worker = Worker_1(worker_1_ready, run_1_workers_mine, run_1_workers_tower, mine_1_worker, repair_1_worker)
                        Worker_1_list.add(red_worker)
                        game_stats['PL1_resources'] -= WORKER_COST

                    # generate archer 1
                    if event.key == pygame.K_e and game_stats['PL1_resources'] >= ARCHER_COST:
                        red_archer = Archer_1(ready_1_archer, run_1_archer, shoot_1_archer, dead_1_archer)
                        Archer_1_list.add(red_archer)
                        game_stats['PL1_resources'] -= ARCHER_COST

                    # unleash soldier 1
                    if event.key == pygame.K_d:
                        for soldier in Soldier_1_list:
                            soldier.unleash = True

                    # unleash worker to mine 1
                    if event.key == pygame.K_a:
                        for red_worker in Worker_1_list:
                            if red_worker.gototower == False:
                                red_worker.gotominer = True

                    # unleash worker to wall2
                    if event.key == pygame.K_s:
                        for red_worker in Worker_1_list:
                            if red_worker.gotominer == False:
                                red_worker.gototower = True

                    # unleash archer 1
                    if event.key == pygame.K_f:
                        for archer in Archer_1_list:
                            archer.unleash = True

                    # unleash all units 1
                    if event.key == pygame.K_z:
                        for red_soldier in Soldier_1_list:
                            red_soldier.unleash = True

                        for red_worker in Worker_1_list:
                            if red_worker.gotominer == False:
                                red_worker.gototower = True

                        for red_archer in Archer_1_list:
                            red_archer.unleash = True

                    # Player 2 units
                    # generate soldier 2
                    if event.key == pygame.K_o and game_stats['PL2_resources'] >= SOLDIER_COST:
                        blue_soldier = Soldier(2, ready_2_soldier, run_2_soldier, attack_2_soldier, dead_2_soldier)
                        Soldier_2_list.add(blue_soldier)
                        game_stats['PL2_resources'] -= SOLDIER_COST

                    # generate worker 2
                    if event.key == pygame.K_p and game_stats['PL2_resources'] >= WORKER_COST:  # blue workers
                        blue_worker = Worker_2(ready_2_worker, run_2_workers_mine, run_2_workers_tower, mine_2_worker,repair_2_worker)
                        Worker_2_list.add(blue_worker)
                        game_stats['PL2_resources'] -= WORKER_COST

                    # generate archer 2
                    if event.key == pygame.K_i and game_stats['PL2_resources'] >= ARCHER_COST:
                        blue_archer = Archer_2(ready_2_archer, run_2_archer, shoot_2_archer, dead_2_archer)
                        Archer_2_list.add(blue_archer)
                        game_stats['PL2_resources'] -= ARCHER_COST

                    # unleash soldier 2
                    if event.key == pygame.K_j:
                        for soldier in Soldier_2_list:
                            soldier.unleash = True

                    # unleash worker to mine 2
                    if event.key == pygame.K_l:
                        for blue_worker in Worker_2_list:
                            if blue_worker.gototower == False:
                                blue_worker.gotominer = True

                    # unleash worker to wall 2
                    if event.key == pygame.K_k:
                        for blue_worker in Worker_2_list:
                            if blue_worker.gotominer == False:
                                blue_worker.gototower = True

                    # unleash archer 2
                    if event.key == pygame.K_h:
                        for archer in Archer_2_list:
                            archer.unleash = True

                    # unleash all units 2
                    if event.key == pygame.K_m:
                        for blue_soldier in Soldier_2_list:
                            blue_soldier.unleash = True

                        for blue_worker in Worker_2_list:
                            if blue_worker.gotominer == False:
                                blue_worker.gototower = True

                        for blue_archer in Archer_2_list:
                            blue_archer.unleash = True

        # detect when to shoot an arrow

        for soldier in Soldier_2_list:
            # when a soldier 2 enter range 1
            if soldier.rect.x == TOWER_RANGE_1:
                enemy_in_range_pos_1 = True
                if enemy_in_range_pos_1 == True:
                    Tower_1_arrows_list_pos_1.add(Tower_1_arrows_pos_1(tower_1_arrows_pos_1))

            # when a soldier 2 enter range 2
            if soldier.rect.x == TOWER_RANGE_2:
                enemy_in_range_pos_2 = True
                if enemy_in_range_pos_2 == True:
                    Tower_1_arrows_list_pos_2.add(Tower_1_arrows_pos_2(tower_1_arrows_pos_2))

        for soldier in Soldier_1_list:
            # when a soldier 1 enter range 1
            if soldier.rect.x == WIDTH - TOWER_RANGE_1:
                enemy_in_range_pos_1 = True
                if enemy_in_range_pos_1 == True:
                    Tower_2_arrow_list_pos_1.add(Tower_2_arrow_pos_1(tower_2_arrow_pos_1))

            # when a soldier 1 enter range 2
            if soldier.rect.x == WIDTH - TOWER_RANGE_2:
                enemy_in_range_pos_2 = True
                if enemy_in_range_pos_2 == True:
                    Tower_2_arrow_list_pos_2.add(Tower_2_arrow_pos_2(tower_2_arrow_pos_2))

        # manage the soldiers hit to the enemy tower and its health
        for red_soldier in Soldier_1_list:
            if red_soldier.is_attack_tower == True:
                Tower_2_bluehealth_count += 1
                if Tower_2_bluehealth_count == 100:
                    Tower_2_bluehealth_count = 0
                    game_stats['Tower_2_blue_health'] -= SOLDIER_HIT
                    if game_stats['Tower_2_blue_health'] <= 0:
                        # finish game when tower's health drop to 0
                        finish_game_red()

        for blue_soldier in Soldier_2_list:
            if blue_soldier.is_attack_tower == True:
                Tower_1_redhealth_count += 1
                if Tower_1_redhealth_count == 100:
                    Tower_1_redhealth_count = 0
                    game_stats['Tower_1_red_health'] -= SOLDIER_HIT
                    if game_stats['Tower_1_red_health'] <= 0:
                        # finish game when tower's health drop to 0
                        finish_game_blue()

        # manage the amount of resources of workers and the tower repair

        # player 1
        for red_worker in Worker_1_list:
            if red_worker.is_at_mine == True:
                counter_1 += 1
                if counter_1 == 100:
                    counter_1 = 0
                    game_stats['PL1_resources'] += WORKER_PROD
                    total_resources_1 += WORKER_PROD

            if red_worker.is_at_wall == True:
                Tower_1_redcount += 1
                if Tower_1_redcount == 100:
                    Tower_1_redcount = 0
                    game_stats['Tower_1_red_health'] += WORKER_REPAIR
                    if game_stats['Tower_1_red_health'] >= TOWER_HEALTH:
                        game_stats['Tower_1_red_health'] = TOWER_HEALTH

        # player 2
        for blue_worker in Worker_2_list:
            if blue_worker.is_at_mine == True:
                counter_2 += 1
                if counter_2 == 100:
                    counter_2 = 0
                    game_stats['PL2_resources'] += WORKER_PROD
                    total_resources_2 += WORKER_PROD

            if blue_worker.is_at_wall == True:
                Tower_2_bluecount += 1
                if Tower_2_bluecount == 100:
                    Tower_2_bluecount = 0
                    game_stats["Tower_2_blue_health"] += WORKER_REPAIR
                    if game_stats["Tower_2_blue_health"] >= TOWER_HEALTH:
                        game_stats["Tower_2_blue_health"] = TOWER_HEALTH

        # manage when to shoot an arrow

        # player 1
        for archer in Archer_1_list:
            if archer.isshoot == True:
                Arrow_1_counter += 1
                if Arrow_1_counter == ARCHER_REST:
                    Arrow_1_list.add(Arrow_1(arrow_1))
                if Arrow_1_counter == 230:
                    Arrow_1_counter = 0

        # player 2
        for archer in Archer_2_list:
            if archer.isshoot == True:
                Arrow_2_counter += 1
                if Arrow_2_counter == ARCHER_REST:
                    Arrow_2_list.add(Arrow_2(arrow_2))
                if Arrow_2_counter == 230:
                    Arrow_2_counter = 0

        # manage arrow hit to the enemy tower and its health

        # player 1
        for arrow in Arrow_1_list:
            if pygame.sprite.spritecollideany(arrow, Tower_2_blue_list):
                Arrow_1_list.remove(arrow)
                game_stats['Tower_2_blue_health'] -= ARCHER_HIT
                if game_stats['Tower_2_blue_health'] <= 0:
                    finish_game_red()

        # player 2
        for arrow in Arrow_2_list:
            if pygame.sprite.spritecollideany(arrow, Tower_1_red_list):
                Arrow_2_list.remove(arrow)
                game_stats['Tower_1_red_health'] -= ARCHER_HIT
                if game_stats['Tower_1_red_health'] <= 0:
                    finish_game_blue()

        # update game state and render game grapichs
        manage_soldiers(Soldier_1_list, Soldier_2_list, Tower_1_red_list, Tower_2_blue_list)
        manage_workers(Worker_1_list, Worker_2_list, Mine_1_red_list, Mine_2_blue_list, Tower_1_red_list, Tower_2_blue_list)
        manage_archers(Soldier_1_list, Soldier_2_list, Archer_1_list, Archer_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2, Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2)

        draw_window(GAME_START, game_stats, Soldier_1_list, Soldier_2_list, Worker_1_list, Worker_2_list, Archer_1_list, Archer_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2, Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2, Tower_1_red_list, Tower_2_blue_list, Mine_1_red_list, Mine_2_blue_list)


# If player 1 win
def finish_game_blue():

    finish_game_text = winning_font.render('BLUE WON', True, BLUE)
    finish_game_rect = finish_game_text.get_rect()
    finish_game_rect.center = (WIDTH // 2, HEIGHT // 2)

    play_again_text = font_number1.render('press "enter" to play again', True, "WHITE")
    play_again_rect = play_again_text.get_rect()
    play_again_rect.center = (WIDTH // 2, HEIGHT // 2 + 40)

    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 128))


    # DISPLAY ALL
    DISPLAYSURF.blit(overlay, (0, 0))
    DISPLAYSURF.blit(finish_game_text, finish_game_rect)
    DISPLAYSURF.blit(play_again_text, play_again_rect)

    pygame.display.update()

    play_again = False
    while not play_again:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:

                main()  # Play again the game
            if event.type == pygame.QUIT:
                sys.exit()

# If player 2 win
def finish_game_red():

    finish_game_text = winning_font.render('RED WON', True, RED)
    finish_game_rect = finish_game_text.get_rect()
    finish_game_rect.center = (WIDTH // 2, HEIGHT // 2)

    play_again_text = font_number1.render('press "enter" to play again', True, "WHITE")
    play_again_rect = play_again_text.get_rect()
    play_again_rect.center = (WIDTH // 2, HEIGHT //2 + 40)

    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 128))

    # DISPLAY ALL
    DISPLAYSURF.blit(overlay, (0,0))
    DISPLAYSURF.blit(finish_game_text, finish_game_rect)
    DISPLAYSURF.blit(play_again_text, play_again_rect)

    pygame.display.update()

    play_again = False
    while not play_again:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:

                main() # Start a new game

            if event.type == pygame.QUIT:
                sys.exit()

# To run the program
if __name__ == '__main__':
    main()

